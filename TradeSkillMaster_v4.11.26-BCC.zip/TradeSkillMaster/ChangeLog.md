## v4.11.26 Changes

* [Classic] Fix incorrect disenchantables

[Known Issues](https://support.tradeskillmaster.com/en_US/known_issues)
